Vimaksh brand pack 0.1.0

Mark and wordmark: SVG and PNG at 1x, 2x and 4x, only in the colours work.vimaksh.in uses.
Pixel motifs: drawn by the website's own code, PNG (scaled with nearest-neighbour) and SVG.
3D logo: vimaksh-logo-sculpture.glb (glTF binary).
Fonts: Inter Tight (variable) and JetBrains Mono 500, both SIL Open Font License 1.1 (licence files included).
Rules: https://raw.githubusercontent.com/VimakshHQ/vimaksh-design-system/main/dist/docs/Brand.md
The Vimaksh name, mark and wordmark belong to Vimaksh. They are not covered by the font licences.
